$(document).ready(function() {
   // initiate tool tip
	// basic usage  
	$('.normaltip').aToolTip();  
	
	$('#form_1').jqTransform({imgPath:'jqtransformplugin/img/'});	
 });